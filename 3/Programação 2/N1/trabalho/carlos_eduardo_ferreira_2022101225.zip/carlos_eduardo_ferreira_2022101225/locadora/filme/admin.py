from django.contrib import admin
from .models import Generos,Filmes
# Register your models here.
admin.site.register(Generos)
admin.site.register(Filmes)
